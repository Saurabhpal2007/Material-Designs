# Internal

> WARNING ⚠️ This folder contains internal features that have limited support.
> Proceed with caution when using them in a project.
>
> Breaking changes may occur that do not bump the major version (vX.0.0).
